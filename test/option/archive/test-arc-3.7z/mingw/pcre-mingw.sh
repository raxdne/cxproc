#
#
#
PREFIX=`pwd`/..

./configure --prefix=$PREFIX --disable-cpp --enable-utf

make -j 4 -k clean install
