
Order of compilation

+ optional libraries

++ zlib-mingw.sh

++ openssl-mingw.sh

++ pthreads-mingw.sh

++ sqlite-mingw.sh

+ required libraries

++ pcre-mingw.sh

++ libiconv-mingw.sh

++ libxml2-mingw.sh

;--- fix link option to >>-lz<< instead of >>-lzdll<<

++ libxslt-mingw.sh

;--- Problems when using other prefix than >>..<<

++ post-mingw.sh

;--- build .def files for using DLL with VC++

+ Binary

++ cxproc-mingw.sh

