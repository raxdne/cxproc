#
#
#
PREFIX=`pwd`/../trunk
#PREFIX='C:\User\develop\cxproc-build\trunk'

cd win32

cscript configure.js compiler=mingw incdir=$PREFIX/include libdir=$PREFIX/lib bindir=$PREFIX/bin sodir=$PREFIX/bin trio=no xslt_debug=no mem_debug=no debugger=no iconv=yes zlib=yes crypto=yes modules=no locale=no

mkdir int.mingw
mkdir int.a.mingw

mkdir int.xslt.mingw
mkdir int.xslta.mingw
mkdir int.exslt.mingw
mkdir int.exslta.mingw
mkdir int.utils.mingw

mkdir bin.mingw

mkdir $PREFIX/include/libxslt
mkdir $PREFIX/bin
mkdir $PREFIX/lib

# dont call targets with commands starting "cmd.exe /c ..." because of failed exit to parent bash
#make -p -f Makefile.mingw > ../t.mak
make -j 4 -f Makefile.mingw dep libxslt libxslta utils

cp ../libxslt/*.h $PREFIX/include/libxslt

cp bin.mingw/libxslt.a $PREFIX/lib
cp bin.mingw/libxslt.lib $PREFIX/lib

cp bin.mingw/libxslt.dll $PREFIX/bin
cp bin.mingw/xslt*.exe $PREFIX/bin

cd ..
