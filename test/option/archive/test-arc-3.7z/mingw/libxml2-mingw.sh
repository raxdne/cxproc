#
#
#
PREFIX=`pwd`/../trunk
#PREFIX='C:\User\develop\cxproc-build\trunk'

cd win32

cscript configure.js compiler=mingw incdir=$PREFIX/include libdir=$PREFIX/lib bindir=$PREFIX/bin sodir=$PREFIX/bin c14n=yes catalog=yes debug=no ftp=yes html=yes http=yes iconv=yes icu=no legacy=no mem_debug=no output=yes pattern=yes push=yes python=no reader=yes regexps=yes run_debug=no sax1=yes schemas=yes schematron=yes tree=yes valid=yes writer=yes xinclude=yes xpath=yes xptr=yes modules=no zlib=yes

mkdir int.mingw
mkdir int.a.mingw
mkdir int.utils.mingw
mkdir bin.mingw

mkdir $PREFIX/include/libxml
mkdir $PREFIX/bin
mkdir $PREFIX/lib

# dont call targets with commands starting "cmd.exe /c ..." because of failed exit to parent bash
#make -j 4 -f Makefile.mingw all
make -f Makefile.mingw all

cp ../include/libxml/*.h $PREFIX/include/libxml

cp bin.mingw/libxml2.a $PREFIX/lib
cp bin.mingw/libxml2.lib $PREFIX/lib

cp bin.mingw/libxml2.dll $PREFIX/bin
cp bin.mingw/xml*.exe $PREFIX/bin

cd ..
