#
#
#
PREFIX=`pwd`/..

export CPPFLAGS="-I$PREFIX/include -I."
export LDFLAGS="-L$PREFIX/lib"
./configure --prefix=$PREFIX

make -j 4 -k install
