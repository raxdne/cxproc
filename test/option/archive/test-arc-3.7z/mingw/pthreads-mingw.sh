#
#
#
PREFIX=`pwd`/..

make clean GC

cp pthread*.dll $PREFIX/bin
cp libpthread*.a $PREFIX/lib
cp pthread.h sched.h semaphore.h $PREFIX/include
