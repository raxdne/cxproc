#
#
#
PREFIX=`pwd`/..

./config shared no-gost --prefix=$PREFIX

make -j 4 -k clean all install_sw
