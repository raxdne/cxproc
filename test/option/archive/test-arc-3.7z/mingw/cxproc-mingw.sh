#
#
#
PREFIX=`pwd`/..

#

#export CPPFLAGS="-Ilib `pkg-config --cflags libxml-2.0 libxslt libpcre vorbis id3tag $IMAGICK $LIBXUL`" 
export CFLAGS=
export CPPFLAGS="-I$PREFIX/include -I$PREFIX/include/libxml2 -Ilib -I."
export LDFLAGS="-L$PREFIX/lib"

test -f Makefile.am || cp build/Makefile.am Makefile.am

test -f configure.ac || cp build/configure.ac configure.ac 

test -d debian || (mkdir debian ; touch debian/DUMMY)

autoheader

aclocal

automake -a

autoconf

./configure --without-profile --with-debug --without-magick --without-vorbis --without-id3tag --without-js --without-sqlite --with-pthread --prefix=$PREFIX

#make install
#make clean all

#mv cxproc.exe $PREFIX/bin
