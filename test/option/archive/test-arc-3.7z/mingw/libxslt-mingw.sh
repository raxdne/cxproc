#
#
#
PREFIX=`pwd`/..

export CPPFLAGS="-I$PREFIX/include -I. -DIN_LIBXML"
export LDFLAGS="-L$PREFIX/lib"
./configure --prefix=$PREFIX --without-python --with-libxml-src=../libxml2-2.7.8

make -C libxslt -j 4 -k install

make -C libexslt -j 4 -k install

make -C xsltproc -j 4 -k install-binPROGRAMS
