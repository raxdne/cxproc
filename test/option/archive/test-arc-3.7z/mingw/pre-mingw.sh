#
#
#

PREFIX=..
DIR_ZIP=/e/Download

for TAR in libiconv-1.14.tar.gz libxml2-2.7.8.tar.gz libxslt-1.1.26.tar.gz openssl-1.0.1c.tar.gz pcre-8.31.tar.gz pthreads-w32-2-9-1-release.tar.gz zlib-1.2.7.tar.gz sqlite/sqlite-autoconf-3071300.tar.gz ; do \
    # wget ...
    tar xzf $DIR_ZIP/$TAR
done

