#
#
#
PREFIX=`pwd`/..

make -f win32/Makefile.gcc minigzip.exe install BINARY_PATH=$PREFIX/bin INCLUDE_PATH=$PREFIX/include LIBRARY_PATH=$PREFIX/lib SHARED_MODE=1

cp minigzip.exe $PREFIX/bin
