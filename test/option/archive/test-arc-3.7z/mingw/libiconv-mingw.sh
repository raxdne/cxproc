#
#
#
PREFIX=`pwd`/..

./configure --prefix=$PREFIX --enable-shared
# --enable-static  --disable-rpath --disable-fast-install

make install-lib
