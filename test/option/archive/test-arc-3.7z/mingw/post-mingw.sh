#
#
#

for DLL in *.dll ; do \
	echo dlltool.exe -z $DLL.def --export-all-symbol $DLL
done

# Test with VC++: "DUMPBIN /EXPORTS libxml2-2.dll > libxml2-2.def"
