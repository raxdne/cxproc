
test -d trunk || (echo "No trunk/ directory" ; exit)

sh trunk/build/mingw/pre-mingw.sh 

(cd zlib-1.2.7/ && sh ../trunk/build/mingw/zlib-mingw.sh)

(cd pthreads-w32-2-9-1-release/ && sh ../trunk/build/mingw/pthreads-mingw.sh)

(cd libiconv-1.14/ && sh ../trunk/build/mingw/libiconv-mingw.sh)

(cd pcre-8.31/ && sh ../trunk/build/mingw/pcre-mingw.sh)

(cd openssl-1.0.1c/ && sh ../trunk/build/mingw/openssl-mingw.sh)

(cd libxml2-2.7.8/ && sh ../trunk/build/mingw/libxml2-mingw.sh)

(cd libxslt-1.1.26/ && sh ../trunk/build/mingw/libxslt-mingw.sh)

(cd sqlite-autoconf-3071300/ && sh ../trunk/build/mingw/sqlite-mingw.sh)

(cd trunk/ && sh build/mingw/cxproc-mingw.sh)

#(cd bin && sh trunk/build/mingw/post-mingw.sh)
