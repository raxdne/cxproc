<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1246029446945" MODIFIED="1246029446945" TEXT="New Mindmap">
<node CREATED="1246029449314" MODIFIED="1246029465333" POSITION="right" TEXT="AAA">
<attribute NAME="date" VALUE="2009"/>
<node CREATED="1246696176381" MODIFIED="1246696179283" TEXT="UUUUU">
<node CREATED="1246029453154" MODIFIED="1246696495219" TEXT="WWWW">
<attribute NAME="done" VALUE="2008"/>
</node>
</node>
</node>
<node CREATED="1246029453154" MODIFIED="1246029477290" POSITION="right" TEXT="BBB">
<attribute NAME="done" VALUE="2008"/>
</node>
<node CREATED="1246029454571" MODIFIED="1246029456111" POSITION="right" TEXT="CCC">
<node CREATED="1246029607591" MODIFIED="1246696804943" TEXT="DDDD">
<attribute NAME="date" VALUE="2010"/>
<attribute NAME="effort" VALUE="7"/>
<node CREATED="1246029607591" MODIFIED="1246696845677" TEXT="DDDD">
<attribute NAME="date" VALUE="2010"/>
<attribute NAME="href" VALUE="http://"/>
</node>
</node>
</node>
<node CREATED="1246029607591" MODIFIED="1246029620676" POSITION="left" TEXT="DDDD">
<attribute NAME="date" VALUE="2010"/>
</node>
</node>
</map>
